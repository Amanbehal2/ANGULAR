package com.cg.kafka.bean;

public class UserModel1 
{
//	private String FullName;
//	
//	private String PAN;
//
//	public UserModel1() {
//		
//	}
//
//	public UserModel1(String fullName, String pAN) {
//		super();
//		FullName = fullName;
//		PAN = pAN;
//	}
//
//	public String getFullName() {
//		return FullName;
//	}
//
//	public void setFullName(String fullName) {
//		FullName = fullName;
//	}
//
//	public String getPAN() {
//		return PAN;
//	}
//
//	public void setPAN(String pAN) {
//		PAN = pAN;
//	}
//
//	@Override
//	public String toString() {
//		return "UserModel1 [FullName=" + FullName + ", PAN=" + PAN + "]";
//	}
	
	
}
