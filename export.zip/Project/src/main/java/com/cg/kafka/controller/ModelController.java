package com.cg.kafka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.kafka.bean.Model;
import com.cg.kafka.bean.UserModel1;


@RestController
@RequestMapping(value = "/Kafka")
public class ModelController 
{

	@Autowired
	
	 KafkaTemplate<String, Model> KafkaJsontemplate;
	 String TOPIC_NAME = "Model";
	 

	
	@PostMapping(value = "/send",consumes = {"application/json"},produces = {"application/json"})
	public String producer(@RequestBody Model model) 
	{
		KafkaJsontemplate.send(TOPIC_NAME, new Model(model.getFirstName(),model.getLastName(),model.getAddress(),model.getShoppingInterest()));
		System.out.println(model.getFirstName());
		
		return "Message published";
	}
	
}
