package com.example.UserInterface;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.bean1.Model1;
import com.example.service.Model1Service;


@RestController
@RequestMapping("kafka")
public class Model1Controller {
  
	@Autowired
  private Model1Service model11;
  
	@KafkaListener(topics="kafka_Example",groupId ="group_json",containerFactory="kafkaListenerContainerFactory")
	public void consumeJson(Model1 model1 ) {
		System.out.println("consumer message"+model1);
	      model11.adduser(model1);
	}

  }

