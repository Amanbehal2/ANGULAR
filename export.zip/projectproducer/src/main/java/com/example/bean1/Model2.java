package com.example.bean1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Model2")
public class Model2 {
   @Id
   @GeneratedValue(strategy=GenerationType.AUTO)
	private int id; 
@Column(name="FullName")
private String FullName;
@Column(name="PAN")

private long PAN;
@Column(name="Address")
private String Address;

public Model2(int id, String fullName, long pAN, String address) {
	super();
	this.id = id;
	FullName = fullName;
	PAN = pAN;
	Address = address;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFullName() {
	return FullName;
}
public void setFullName(String fullName) {
	FullName = fullName;
}
public long getPAN() {
	return PAN;
}
public void setPAN(long PAN) {
	this.PAN = PAN;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}

}
