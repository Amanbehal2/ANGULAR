package com.example.service;

import java.util.List;

import com.example.bean1.Model1;

public interface Model1Service {
	public int adduser(Model1 modeluser);
	public List<Model1> showall();

}
