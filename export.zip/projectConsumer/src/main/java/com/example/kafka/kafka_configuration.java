package com.example.kafka;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

import com.example.bean1.Model1;
import com.fasterxml.jackson.databind.JsonDeserializer;
@EnableKafka
@Configuration
public class kafka_configuration {

	@Bean
	public ConsumerFactory<String, Model1> ConsumerFactory(){
		Map<String,Object> config=new HashMap<>();
		config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"127.0.0.1:9092");
		config.put(ConsumerConfig.GROUP_ID_CONFIG,"group_json");
		config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class);
		config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
	     return new DefaultKafkaConsumerFactory<>(config,new StringDeserializer(),new org.springframework.kafka.support.serializer.JsonDeserializer<>(Model1.class));
	}
	@Bean 
	public ConcurrentKafkaListenerContainerFactory<String,Model1> kafkaListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String,Model1> Factory=new ConcurrentKafkaListenerContainerFactory< >();
		Factory.setConsumerFactory(ConsumerFactory());
		return Factory;
	}
	
}
