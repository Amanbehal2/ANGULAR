package com.example.bean1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Model1")

public class Model1 {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@Column(name="First_Name")
	private String First_Name;
	@Column(name="Last_Name")
	private String Last_Name;
	@Column(name="Address_1")
	private String Address_1;
	@Column(name="Address_2")
	private String Address_2;
	@Column(name="Shopping_Interest")
	private String Shopping_Interests;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Model1(int id, String first_Name, String last_Name, String address_1, String address_2,
			String shopping_Interests) {
		super();
		this.id = id;
		First_Name = first_Name;
		Last_Name = last_Name;
		Address_1 = address_1;
		Address_2 = address_2;
		Shopping_Interests = shopping_Interests;
	}
	public String getFirst_Name() {
		return First_Name;
	}
	public void setFirst_Name(String first_Name) {
		First_Name = first_Name;
	}
	public String getLast_Name() {
		return Last_Name;
	}
	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}
	public String getAddress_1() {
		return Address_1;
	}
	public void setAddress_1(String address_1) {
		Address_1 = address_1;
	}
	public String getAddress_2() {
		return Address_2;
	}
	public void setAddress_2(String address_2) {
		Address_2 = address_2;
	}
	public String getShopping_Interests() {
		return Shopping_Interests;
	}
	public void setShopping_Interests(String shopping_Interests) {
		Shopping_Interests = shopping_Interests;
	}
	
	

	
	
}
